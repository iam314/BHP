class AddPositionToMorePictures < ActiveRecord::Migration
  def change
 	add_column :more_pictures, :position, :integer
  end
end
