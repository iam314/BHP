class AddCheckboxToMorePictures < ActiveRecord::Migration
  def change
  	add_column :more_pictures, :on_new_line, :boolean
  end
end
