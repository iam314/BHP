class CreatePlatePictures < ActiveRecord::Migration
  def change
    create_table :plate_pictures do |t|
      t.integer :plate_row_id
      t.string :picture

      t.timestamps
    end
  end
end
