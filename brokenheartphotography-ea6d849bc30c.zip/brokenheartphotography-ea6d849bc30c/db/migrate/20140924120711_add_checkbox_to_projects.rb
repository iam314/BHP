class AddCheckboxToProjects < ActiveRecord::Migration
  def change
  	add_column :projects, :on_new_line, :boolean
  end
end
