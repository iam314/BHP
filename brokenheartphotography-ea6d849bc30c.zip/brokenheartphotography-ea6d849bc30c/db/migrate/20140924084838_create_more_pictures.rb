class CreateMorePictures < ActiveRecord::Migration
  def change
    create_table :more_pictures do |t|
      t.string :picture

      t.timestamps
    end
  end
end
