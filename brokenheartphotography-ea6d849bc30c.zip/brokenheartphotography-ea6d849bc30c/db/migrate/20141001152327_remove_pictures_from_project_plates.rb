class RemovePicturesFromProjectPlates < ActiveRecord::Migration
  def change
  	remove_column :project_plates, :r1pic1
  	remove_column :project_plates, :r1pic2
  	remove_column :project_plates, :r2pic1
  	remove_column :project_plates, :r2pic2
  	remove_column :project_plates, :r2pic3
  end
end
