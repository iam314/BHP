class CreateSliders < ActiveRecord::Migration
  def change
    create_table :sliders do |t|
      t.string :picture

      t.timestamps
    end
  end
end
