class CreatePlateRows < ActiveRecord::Migration
  def change
    create_table :plate_rows do |t|
      t.integer :project_plate_id

      t.timestamps
    end
  end
end
