class CreateProjectPlates < ActiveRecord::Migration
  def change
    create_table :project_plates do |t|
      t.string :title
      t.text :body
      t.string :main_picture
      t.string :r1pic1
      t.string :r1pic2
      t.string :r2pic1
      t.string :r2pic2
      t.string :r2pic3

      t.timestamps
    end
  end
end
