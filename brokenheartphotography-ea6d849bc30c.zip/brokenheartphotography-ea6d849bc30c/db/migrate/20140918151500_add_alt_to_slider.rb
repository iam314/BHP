class AddAltToSlider < ActiveRecord::Migration
  def change
    add_column :sliders, :alt, :string
  end
end