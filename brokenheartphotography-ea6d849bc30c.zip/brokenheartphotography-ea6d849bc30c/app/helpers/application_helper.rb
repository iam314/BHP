module ApplicationHelper

	def title(page_title)
	  content_for(:title) { page_title }
	end

	def navigation_item(name, options)
		if current_page?(options)
			content_tag :li, link_to(h(name), options), :class => "current"
		else
			content_tag :li, link_to(h(name), options)
		end
	end
end
