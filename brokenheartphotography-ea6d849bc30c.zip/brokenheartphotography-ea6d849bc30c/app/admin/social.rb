ActiveAdmin.register Social do

    menu :priority => 8

    index do
        selectable_column

        column :social_type
        column :name
        column :link

        actions
    end

    show do
        attributes_table do

            row :social_type
            row :name
            row :link
        end
    end

    form do |f|
        f.inputs "Content" do
            f.input :social_type
            f.input :name
            f.input :link
        end

        f.actions
    end

          permit_params :name, :link, :social_type

end