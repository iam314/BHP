ActiveAdmin.register PlatePicture do

	permit_params :plate_row_id, :picture, :_destroy

	belongs_to :plate_row
	
end