ActiveAdmin.register MorePicture do
    config.sort_order = 'position_asc'
    config.paginate   = false

    sortable
    menu :priority => 7

    config.filters = false

    index do
        sortable_handle_column

        column :position
        column 'Picture' do |more_picture|
            image_tag more_picture.picture.url :thumb
        end
        column :on_new_line

        actions
    end

    show do
        attributes_table do

            row :picture do
                image_tag more_picture.picture.url :thumb
            end
            row :on_new_line
        end        
    end    
    
    form do |f|
        f.inputs "Content" do
            f.input :picture, label: "Картинка", hint: f.template.image_tag(f.object.picture.url :thumb)
            f.input :on_new_line, :as => :boolean
        end

        f.actions
    end

    permit_params :picture, :on_new_line, :position
end