ActiveAdmin.register ProjectPlate do

    menu :priority => 5

    config.filters = false

    index do
        selectable_column

        column :id
        column :title, label: "Заглавие"
        column :body, label: "Текст"
        column 'Главна Картинка' do |project_plate|
            image_tag project_plate.main_picture.url :thumb
        end

        actions
    end

    show do
        attributes_table do
            row :id
            row :title, label: "Заглавие"
            row :body, label: "Текст"
            row "Главна Картинка" do
                image_tag project_plate.main_picture.url :thumb
            end
            if project_plate.plate_rows.count > 0
                project_plate.plate_rows.each do |ppr|
                    row "Ред" do
                        ul do
                            li do
                                ppr.plate_pictures.map { |plp| image_tag plp.picture_url(:thumb) }.join(" ").html_safe
                            end
                        end
                    end
                end
            else
                h3 "No pictures"
            end
        end
    end

    form do |f|
        f.inputs "Content" do
            f.input :title
            f.input :body
            f.input :main_picture, label: "Главна картинка", hint: f.template.image_tag(f.object.main_picture.url :thumb)
        end
        f.has_many :plate_rows, allow_destroy: true do |ff|
            ff.has_many :plate_pictures, allow_destroy: true do |fff|
                fff.input :picture, label: "Картинка", hint: fff.template.image_tag(fff.object.picture.url :thumb)
            end
        end

        f.actions
    end

    permit_params :_method, :authenticity_token, :title, :body, :main_picture, plate_rows_attributes: [:id, :project_plate_id, :_destroy, plate_pictures_attributes: [:id, :plate_row_id, :picture, :_destroy] ]

end
