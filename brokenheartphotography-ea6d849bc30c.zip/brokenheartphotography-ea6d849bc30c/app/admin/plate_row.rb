ActiveAdmin.register PlateRow do

	permit_params :project_plate_id, plate_pictures_attributes: [:plate_row_id, :picture, :_destroy]

	belongs_to :project_plate
	
end