ActiveAdmin.register Slider do
    menu :priority => 2

    config.filters = false

    index do
        selectable_column

        column :id
        column :alt
        column 'Слайд' do |slider|
            image_tag slider.picture.url :thumb
        end 

        actions
    end

    show do
        attributes_table do
            row :picture do 
                image_tag slider.picture.url :slide
            end
            row :alt
        end        
    end

    form do |f|
        f.inputs "Content" do
            f.input :picture, label: "Картинка", hint: f.object.picture.nil? ? nil : f.template.image_tag(f.object.picture.url :slide)
            f.input :alt
        end

        f.actions
    end    

    permit_params :picture, :alt
    
end
