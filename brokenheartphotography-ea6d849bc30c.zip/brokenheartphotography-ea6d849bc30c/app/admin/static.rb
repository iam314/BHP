ActiveAdmin.register Static do
    actions :all, :except => [:new]

    menu :priority => 3

    index do
        selectable_column

        column :title
        column :body do |static|
            truncate (strip_tags static.body), length: 200
        end

        actions
    end

    show do
        attributes_table do

            row :title
            row :body do
                truncate (strip_tags static.body), length: 200
            end
        end
    end

    form do |f|
        f.inputs "Content" do
            f.input :title
            f.input :body
        end

        f.actions
    end

    permit_params :title, :body

end
