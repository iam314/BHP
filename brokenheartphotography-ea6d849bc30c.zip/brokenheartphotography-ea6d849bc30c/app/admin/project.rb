ActiveAdmin.register Project do
    config.sort_order = 'position_asc'
    config.paginate   = false

    sortable

    menu :priority => 4

    config.filters = false

    index do
        sortable_handle_column

        column :position
        column :title
        column 'Picture' do |project|
            image_tag project.picture.url :thumb
        end 
        column :link
        column :on_new_line

        actions
    end

    show do
        attributes_table do

            row :title
            row :picture do
                image_tag project.picture.url :thumb
            end
            row :link
            row :on_new_line
        end        
    end    
    
    form do |f|
        f.inputs "Content" do
            f.input :title
            f.input :picture, label: "Картинка", hint: f.template.image_tag(f.object.picture.url :thumb)
            f.input :link, :as => :select, :collection => ProjectPlate.all.map{|c| ["Проект #{c.id} #{c.title}", project_plates_path(c)]}
            f.input :on_new_line, :as => :boolean
        end

        f.actions
    end

    permit_params :title, :picture, :link, :on_new_line, :position

end