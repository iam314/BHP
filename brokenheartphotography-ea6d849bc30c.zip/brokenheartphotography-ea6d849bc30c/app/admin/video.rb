ActiveAdmin.register Video do

   menu :priority => 6

    index do
        selectable_column

        column :title
        column :body
        column :video_url

        actions
    end

    show do
        attributes_table do

            row :title
            row :body
            row :video_url
        end        
    end    
    
    form do |f|
        f.inputs "Content" do
            f.input :title
            f.input :body
            f.input :video_url
        end

        f.actions
    end

    permit_params :title, :body, :video_url

end
