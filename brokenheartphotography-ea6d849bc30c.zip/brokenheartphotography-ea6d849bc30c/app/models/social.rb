class Social < ActiveRecord::Base
end
