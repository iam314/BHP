class PlateRow < ActiveRecord::Base

	belongs_to :project_plate

	has_many :plate_pictures, autosave: true, dependent: :destroy

    validates :plate_pictures, presence: true

	accepts_nested_attributes_for :plate_pictures, allow_destroy: true, reject_if: :reject_picture


    def reject_picture(attributed)
        attributed['picture'].blank?
    end
end
