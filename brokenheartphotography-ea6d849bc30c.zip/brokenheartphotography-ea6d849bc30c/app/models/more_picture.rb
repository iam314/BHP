class MorePicture < ActiveRecord::Base

	acts_as_list

	validates :picture, :presence => true

	mount_uploader :picture, ImageUploader
end
