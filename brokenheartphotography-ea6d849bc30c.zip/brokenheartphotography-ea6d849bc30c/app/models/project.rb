class Project < ActiveRecord::Base

	acts_as_list

	has_one :project_plate
	
	validates :picture, :presence => true

	mount_uploader :picture, ImageUploader
end
