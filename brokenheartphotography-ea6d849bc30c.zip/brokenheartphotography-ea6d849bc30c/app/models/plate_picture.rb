class PlatePicture < ActiveRecord::Base

	belongs_to :plate_rows, dependent: :destroy

    validates :picture, presence: true

	mount_uploader :picture, ImageUploader
end
