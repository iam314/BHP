class Slider < ActiveRecord::Base

	mount_uploader :picture, SliderUploader
end
