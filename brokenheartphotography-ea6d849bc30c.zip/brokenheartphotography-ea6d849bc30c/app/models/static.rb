class Static < ActiveRecord::Base
end
