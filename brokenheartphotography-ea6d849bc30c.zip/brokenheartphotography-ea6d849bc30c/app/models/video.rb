class Video < ActiveRecord::Base
end
