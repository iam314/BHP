class ProjectPlate < ActiveRecord::Base

	has_many :plate_rows, autosave: true, dependent: :destroy

	has_many :plate_pictures, through: :plate_row

	belongs_to :project

	accepts_nested_attributes_for :plate_rows, allow_destroy: true

	mount_uploader :main_picture, ImageUploader
end
