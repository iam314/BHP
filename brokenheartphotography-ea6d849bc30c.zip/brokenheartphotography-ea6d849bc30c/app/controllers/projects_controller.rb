class ProjectsController < InheritedResources::Base
    def show
        @project = Project.where(id: params[:id]).first

    end    
end
