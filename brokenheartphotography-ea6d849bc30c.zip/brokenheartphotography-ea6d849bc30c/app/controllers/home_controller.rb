class HomeController < ApplicationController
    def index
        @slider = Slider.all

        @home = Static.where(keyword: 'home').first
        @email = Social.where(social_type: 'Email').first
        @social = Social.all.order(created_at: :desc)
    end

    def project
    	@project = Project.all.order(position: :asc)
    end

    def video
        @video = Video.all.order(created_at: :desc)
    end

    def more
        @more = MorePicture.all.order(position: :asc)
    end

end
