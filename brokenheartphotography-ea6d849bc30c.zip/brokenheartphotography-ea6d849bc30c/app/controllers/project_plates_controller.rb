class ProjectPlatesController < ApplicationController
    def show
        @plate = ProjectPlate.where(id: params[:id]).first

    end
end
