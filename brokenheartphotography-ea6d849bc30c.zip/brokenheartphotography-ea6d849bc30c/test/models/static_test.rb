require 'test_helper'

class StaticTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
