require 'test_helper'

class ProjectPlateHelperTest < ActionView::TestCase
end
