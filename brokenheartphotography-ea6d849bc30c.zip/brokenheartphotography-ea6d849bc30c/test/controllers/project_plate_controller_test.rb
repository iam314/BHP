require 'test_helper'

class ProjectPlateControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
