# config valid only for Capistrano 3.1
lock '3.2.1'

set :application, 'brokenheartphotography'
set :repo_url, "git@whips.bitbucket.org:whips/brokenheartphotography.git"
set :branch, "master"

set :deploy_to, "/home/rails/apps/brokenheartphotography"

set :rvm_type, :user
set :rvm_ruby, '2.0.0-p353'
set :rvm_custom_path, '/usr/local/rvm'  # only needed if not detected

set :linked_files, %w{config/database.yml config/local_env.yml}
set :linked_dirs, %w{bin log tmp/pids tmp/cache tmp/sockets vendor/bundle public/system public/assets public/uploads}